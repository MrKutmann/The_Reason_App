
import React from 'react';
import { ContentItem } from '../types';

interface ProfileViewProps {
  userItems: ContentItem[];
}

const ProfileView: React.FC<ProfileViewProps> = ({ userItems }) => {
  return (
    <div className="fixed inset-0 z-[140] bg-[#050a14] pt-20 pb-32 px-6 overflow-y-auto no-scrollbar animate-in fade-in slide-in-from-right duration-500">
      {/* Profile Header Section */}
      <div className="flex items-start gap-6 mb-12 mt-4 px-2">
        {/* Avatar with Note Bubble */}
        <div className="relative flex-shrink-0">
          {/* Note Bubble */}
          <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-[#1a1d23] border border-white/5 rounded-2xl px-3 py-1.5 text-[10px] text-white/60 shadow-xl z-10 whitespace-nowrap">
            Note...
            <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-[#1a1d23] rotate-45 border-r border-b border-white/5"></div>
          </div>
          
          <div className="w-24 h-24 rounded-full p-1.5 border-[3px] border-[#1a1d23] relative">
            <div className="w-full h-full rounded-full bg-[#34D399] flex items-center justify-center text-black font-black text-2xl overflow-hidden shadow-2xl">
              <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Lucky" alt="Profile" className="w-full h-full object-cover" />
            </div>
            {/* Pro badge moved to avatar corner */}
            <div className="absolute -bottom-1 -right-1 bg-[#6366f1] text-[8px] font-black px-2 py-0.5 rounded-md text-white border border-[#050a14] shadow-lg">
              PRO
            </div>
          </div>
        </div>

        {/* User Info Content */}
        <div className="flex-1 pt-1">
          <div className="flex items-center gap-2 mb-6">
            <h2 className="text-2xl font-bold tracking-tight">John_Mindful</h2>
            <button className="text-white hover:text-white/70 transition-colors">
              <i className="fa-solid fa-gear text-lg"></i>
            </button>
          </div>

          {/* Stats Section - Centered & Bigger */}
          <div className="flex justify-between max-w-[280px] mb-6">
            <div className="flex flex-col items-center">
              <span className="text-xl font-bold leading-none">{userItems.length}</span>
              <span className="text-[12px] text-white/40 font-medium mt-1">posts</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-xl font-bold leading-none">1.2k</span>
              <span className="text-[12px] text-white/40 font-medium mt-1">subscribers</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-xl font-bold leading-none">428</span>
              <span className="text-[12px] text-white/40 font-medium mt-1">following</span>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <i className="fa-solid fa-at text-[10px] text-white/60"></i>
            <span className="text-sm font-semibold text-white/90">john_mindful</span>
          </div>
        </div>
      </div>

      {/* Uploaded Content Section */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4 px-1">
          <h3 className="text-sm font-black uppercase tracking-[0.2em] text-white/20">My Reasons</h3>
        </div>

        {userItems.length > 0 ? (
          <div className="grid grid-cols-3 gap-1">
            {userItems.map((item) => (
              <div 
                key={item.id} 
                className="aspect-[9/16] bg-white/5 rounded-xl overflow-hidden border border-white/5 relative group cursor-pointer"
              >
                {item.type === 'video' ? (
                  <video 
                    src={item.mediaUrl} 
                    className="w-full h-full object-cover opacity-70 group-hover:opacity-100 transition-opacity"
                    muted
                    playsInline
                    onMouseEnter={(e) => e.currentTarget.play()}
                    onMouseLeave={(e) => {
                      e.currentTarget.pause();
                      e.currentTarget.currentTime = 0;
                    }}
                  />
                ) : (
                  <img 
                    src={item.mediaUrl} 
                    alt={item.title} 
                    className="w-full h-full object-cover opacity-70 group-hover:opacity-100 transition-opacity" 
                  />
                )}
                
                {/* Video Indicator Overlay */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-40 group-hover:opacity-0 transition-opacity">
                   <i className="fa-solid fa-play text-xl text-white"></i>
                </div>

                {/* Bottom Stats Overlay */}
                <div className="absolute bottom-2 left-2 flex items-center gap-1 text-[10px] font-bold text-white drop-shadow-lg">
                   <i className="fa-solid fa-play text-[8px]"></i>
                   <span>{item.stats.likes > 1000 ? (item.stats.likes/1000).toFixed(1) + 'k' : item.stats.likes}</span>
                </div>

                {/* History/Restore Icon */}
                <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                   <div className="w-6 h-6 rounded-lg glass-effect flex items-center justify-center text-[8px] border border-white/10">
                      <i className="fa-solid fa-rotate-left"></i>
                   </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 px-10 text-center">
            <div className="w-16 h-16 rounded-full bg-white/[0.02] flex items-center justify-center mb-4 text-white/10">
               <i className="fa-solid fa-cloud-arrow-up text-2xl"></i>
            </div>
            <p className="text-white/40 font-bold text-lg">No reasons, yet</p>
            <p className="text-white/10 text-xs mt-2 uppercase tracking-widest">Contribute to the collective intelligence</p>
          </div>
        )}
      </div>

      {/* Version Info */}
      <p className="text-center text-[10px] text-white/5 uppercase tracking-[0.4em] mt-12 font-bold pb-10">
        MindfulStream v1.0.4
      </p>
    </div>
  );
};

export default ProfileView;
