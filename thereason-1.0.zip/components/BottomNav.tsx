
import React from 'react';

interface BottomNavProps {
  onHomeClick: () => void;
  onUploadClick: () => void;
  onProfileClick: () => void;
  activeView: 'feed' | 'upload' | 'profile';
}

const BottomNav: React.FC<BottomNavProps> = ({ onHomeClick, onUploadClick, onProfileClick, activeView }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-[200] px-4 pb-10 pt-4 flex justify-center items-center pointer-events-none">
      <div className="flex justify-around items-center w-full max-w-[280px] pointer-events-auto bg-black/40 backdrop-blur-xl px-4 py-3 rounded-[32px] border border-white/10 shadow-2xl">
        
        {/* Home Icon */}
        <button 
          onClick={onHomeClick}
          className={`glass-card-stack ${activeView === 'feed' ? 'active' : ''}`}
        >
          <div className="glass-card-layer-back" />
          <div className="glass-card-layer-front">
            <i className="fa-solid fa-house text-base"></i>
          </div>
        </button>

        {/* Upload Icon */}
        <button 
          onClick={onUploadClick}
          className={`glass-card-stack upload ${activeView === 'upload' ? 'active' : ''}`}
        >
          <div className="glass-card-layer-back" />
          <div className="glass-card-layer-front">
            <i className="fa-solid fa-plus text-lg"></i>
          </div>
        </button>

        {/* User Profile Icon */}
        <button 
          onClick={onProfileClick}
          className={`glass-card-stack ${activeView === 'profile' ? 'active' : ''}`}
        >
          <div className="glass-card-layer-back" />
          <div className="glass-card-layer-front">
            <i className="fa-solid fa-user text-base"></i>
          </div>
        </button>

      </div>
    </div>
  );
};

export default BottomNav;
