
import React from 'react';
import { FeedCategory } from '../types';

interface TopNavProps {
  activeCategory: FeedCategory;
  onCategoryChange: (cat: FeedCategory) => void;
}

const categories: FeedCategory[] = ['All', 'Photos', 'Videos', 'Posts'];

const TopNav: React.FC<TopNavProps> = ({ activeCategory, onCategoryChange }) => {
  return (
    <div className="fixed top-0 left-0 right-0 z-50">
      <div className="pt-14 pb-6 relative">
        {/* Category Filters Centered */}
        <div className="w-full px-6 flex items-center justify-center relative z-10">
          <div className="flex gap-8 items-center justify-center">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => onCategoryChange(cat)}
                className={`text-sm transition-all duration-500 whitespace-nowrap tracking-wider uppercase font-bold ${
                  activeCategory === cat 
                    ? 'text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.5)] scale-110 opacity-100' 
                    : 'text-white/30 hover:text-white/50 opacity-60'
                }`}
                style={{
                  fontFamily: "'Inter', sans-serif",
                }}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TopNav;
