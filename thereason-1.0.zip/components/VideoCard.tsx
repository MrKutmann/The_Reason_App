
import React, { useState, useEffect, useRef } from 'react';
import { ContentItem } from '../types';

interface VideoCardProps {
  item: ContentItem;
  isActive: boolean;
}

const VideoCard: React.FC<VideoCardProps> = ({ item, isActive }) => {
  const [liked, setLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(item.stats.likes);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current) {
      if (isActive) {
        videoRef.current.play().catch(error => {
          console.log("Autoplay prevented:", error);
        });
      } else {
        videoRef.current.pause();
        videoRef.current.currentTime = 0;
      }
    }
  }, [isActive]);

  const handleLikeToggle = () => {
    if (liked) {
      setLikesCount(prev => prev - 1);
    } else {
      setLikesCount(prev => prev + 1);
    }
    setLiked(!liked);
  };

  return (
    <div className="relative w-full h-screen flex-shrink-0 bg-black overflow-hidden select-none">
      {/* Media Background */}
      {item.type === 'video' ? (
        <video
          ref={videoRef}
          src={item.mediaUrl}
          className="absolute inset-0 w-full h-full object-cover"
          playsInline
          loop
          muted
          crossOrigin="anonymous"
        />
      ) : (
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${item.mediaUrl})` }}
        />
      )}
      
      {/* Overlay Gradient */}
      <div className="absolute inset-0 mindful-gradient pointer-events-none" />

      {/* Vertical Interaction Sidebar (Right Side) */}
      <div className="absolute right-4 bottom-32 flex flex-col items-center gap-5 z-40">
        
        {/* Profile Avatar */}
        <div className="relative mb-2">
           <div className="glass-card-stack mini">
              <div className="glass-card-layer-back" />
              <div className="glass-card-layer-front !p-0.5 overflow-hidden">
                <img src={item.creator.avatar} alt={item.creator.handle} className="w-full h-full object-cover rounded-[11px]" />
              </div>
           </div>
           <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-4 h-4 bg-[#FF4550] rounded-full flex items-center justify-center text-white text-[8px] z-30 shadow-lg border border-black/20">
             <i className="fa-solid fa-plus"></i>
           </div>
        </div>

        {/* Like */}
        <div className="flex flex-col items-center">
          <button 
            onClick={handleLikeToggle} 
            className={`glass-card-stack mini ${liked ? 'active' : ''}`}
          >
            <div className="glass-card-layer-back" />
            <div className="glass-card-layer-front">
              <i className={`fa-solid fa-heart transition-all duration-300 ${liked ? '!text-red-400 text-base scale-110' : 'text-sm opacity-70'}`}></i>
            </div>
          </button>
          <span className="text-[11px] font-bold text-white mt-1 drop-shadow-md transition-all">
            {likesCount.toLocaleString()}
          </span>
        </div>

        {/* Comments */}
        <div className="flex flex-col items-center">
          <button className="glass-card-stack mini">
            <div className="glass-card-layer-back" />
            <div className="glass-card-layer-front">
              <i className="fa-solid fa-comment-dots text-sm opacity-70"></i>
            </div>
          </button>
          <span className="text-[11px] font-bold text-white mt-1 drop-shadow-md">{item.stats.comments.toLocaleString()}</span>
        </div>

        {/* Shares */}
        <div className="flex flex-col items-center">
          <button className="glass-card-stack mini">
            <div className="glass-card-layer-back" />
            <div className="glass-card-layer-front">
              <i className="fa-solid fa-share-nodes text-sm opacity-70"></i>
            </div>
          </button>
          <span className="text-[11px] font-bold text-white mt-1 drop-shadow-md">{item.stats.shares.toLocaleString()}</span>
        </div>

        {/* Music Disc */}
        <button className="glass-card-stack mini">
          <div className="glass-card-layer-back" />
          <div className="glass-card-layer-front animate-spin-slow">
             <i className="fa-solid fa-compact-disc text-lg opacity-70"></i>
          </div>
        </button>
      </div>

      {/* Content Info (Bottom Left) */}
      <div className="absolute left-6 bottom-32 right-20 z-30 pointer-events-none text-left">
        <h3 className="text-lg font-bold text-white mb-1 drop-shadow-md">
          {item.creator.handle}
        </h3>
        <p className="text-sm text-white/90 line-clamp-2 mb-3 drop-shadow-sm max-w-xs">
          {item.title} — {item.description}
        </p>
        <div className="flex items-center gap-2 text-[10px] text-white/60 uppercase tracking-widest">
          <i className="fa-solid fa-music"></i>
          <span className="truncate">Intellectual Discourse - Mindful Soundscape</span>
        </div>
      </div>
    </div>
  );
};

export default VideoCard;
