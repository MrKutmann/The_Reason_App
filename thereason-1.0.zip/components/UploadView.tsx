
import React, { useState, useRef } from 'react';
import { vetContent } from '../services/geminiService';
import { ContentItem } from '../types';
import { COLORS } from '../constants';

interface UploadViewProps {
  onClose: () => void;
  onPost: (item: ContentItem) => void;
}

const UploadView: React.FC<UploadViewProps> = ({ onClose, onPost }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isVetting, setIsVetting] = useState(false);
  const [vettingResult, setVettingResult] = useState<{ isMindful: boolean; score: number; reason: string } | null>(null);
  const [selectedVideo, setSelectedVideo] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setSelectedVideo(url);
      setVettingResult(null);
    }
  };

  const captureFrame = (): string | null => {
    if (!videoRef.current || !canvasRef.current) return null;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    // Get base64 data without the prefix
    return canvas.toDataURL('image/jpeg', 0.8).split(',')[1];
  };

  const handleVetting = async () => {
    if (!selectedVideo) return;
    
    setIsVetting(true);
    
    // Capture the frame currently shown in the video preview
    const frameData = captureFrame();
    const imagePart = frameData ? {
      inlineData: {
        data: frameData,
        mimeType: 'image/jpeg'
      }
    } : undefined;

    const result = await vetContent({ title, description, type: 'video' }, imagePart);
    setVettingResult(result);
    setIsVetting(false);
  };

  const handleFinalPublish = () => {
    if (!vettingResult || !selectedVideo) return;
    
    const newItem: ContentItem = {
      id: Date.now().toString(),
      type: 'video',
      title: title || 'Untitled Wisdom',
      description: description || 'Sharing mindful insights with the world.',
      creator: {
        name: 'You',
        handle: '@mindful_explorer',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Lucky'
      },
      mediaUrl: selectedVideo,
      stats: { likes: 0, comments: 0, shares: 0 },
      mindfulScore: vettingResult.score,
      vettingStatus: 'vetted'
    };
    
    onPost(newItem);
  };

  return (
    <div className="fixed inset-0 z-[150] bg-[#050a14]/95 backdrop-blur-3xl flex flex-col pt-16 pb-32 px-6 overflow-y-auto no-scrollbar animate-in fade-in slide-in-from-bottom duration-500">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Post Content</h1>
        <button onClick={onClose} className="text-white/60 hover:text-white transition-colors">
          <i className="fa-solid fa-xmark text-2xl"></i>
        </button>
      </div>

      <div className="space-y-6">
        <input 
          type="file" 
          accept="video/*" 
          className="hidden" 
          ref={fileInputRef} 
          onChange={handleFileChange} 
        />
        
        {/* Hidden Canvas for frame extraction */}
        <canvas ref={canvasRef} className="hidden" />
        
        <div 
          onClick={() => !selectedVideo && fileInputRef.current?.click()}
          className={`relative w-full aspect-[9/16] max-h-[400px] bg-white/5 border-2 border-dashed border-white/10 rounded-[32px] flex flex-col items-center justify-center group cursor-pointer transition-all overflow-hidden ${selectedVideo ? 'border-solid border-[#E4FF1A]/30' : 'hover:border-[#E4FF1A]/50'}`}
        >
          {selectedVideo ? (
            <>
              <video 
                ref={videoRef}
                src={selectedVideo} 
                className="w-full h-full object-cover" 
                controls
                autoPlay
                muted
                loop
              />
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedVideo(null);
                  setVettingResult(null);
                }}
                className="absolute top-4 right-4 w-10 h-10 rounded-full bg-black/60 text-white flex items-center justify-center backdrop-blur-md border border-white/10"
              >
                <i className="fa-solid fa-trash-can"></i>
              </button>
            </>
          ) : (
            <>
              <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <i className="fa-solid fa-video text-3xl text-white/40 group-hover:text-[#E4FF1A]"></i>
              </div>
              <p className="text-sm text-white/40 font-bold uppercase tracking-widest">Upload Video</p>
              <span className="text-[10px] text-white/20 mt-1 uppercase tracking-widest text-center px-4">AI will scan the video for intellectual context</span>
            </>
          )}
        </div>

        <div className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-[10px] uppercase tracking-[0.2em] font-black text-white/30 ml-1">Title</label>
              <span className="text-[9px] text-white/10 uppercase font-bold">Optional</span>
            </div>
            <input 
              type="text" 
              placeholder="Give your insight a name..." 
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-4 text-white placeholder:text-white/20 focus:outline-none focus:border-[#E4FF1A]/50 transition-all"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>

          <div>
             <div className="flex justify-between items-center mb-2">
              <label className="text-[10px] uppercase tracking-[0.2em] font-black text-white/30 ml-1">Summary</label>
              <span className="text-[9px] text-white/10 uppercase font-bold">Optional</span>
            </div>
            <textarea 
              rows={2}
              placeholder="What can we learn from this?" 
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-4 text-white placeholder:text-white/20 focus:outline-none focus:border-[#E4FF1A]/50 resize-none transition-all"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
        </div>

        {!vettingResult ? (
          <button 
            disabled={isVetting || !selectedVideo}
            onClick={handleVetting}
            className={`w-full py-5 rounded-[28px] font-black tracking-widest flex items-center justify-center gap-3 transition-all ${
              isVetting || !selectedVideo 
                ? 'bg-white/5 border border-white/10 text-white/20' 
                : 'bg-[#E4FF1A] text-black hover:scale-[1.02] active:scale-[0.98] shadow-[0_0_20px_rgba(228,255,26,0.3)]'
            }`}
          >
            {isVetting ? (
              <>
                <i className="fa-solid fa-brain animate-pulse"></i>
                VETTING...
              </>
            ) : (
              <>
                <i className="fa-solid fa-robot text-lg"></i>
                Make a Reason
              </>
            )}
          </button>
        ) : (
          <div className={`p-6 rounded-[32px] border animate-in zoom-in duration-300 ${vettingResult.isMindful ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
            <div className="flex justify-between items-center mb-3">
              <span className="text-[10px] font-black uppercase tracking-widest text-white/50">Vetting Result</span>
              <div className="flex items-center gap-2">
                 <span className={`text-2xl font-black ${vettingResult.isMindful ? 'text-green-400' : 'text-red-400'}`}>
                  {vettingResult.score.toFixed(1)}
                </span>
                <span className="text-xs text-white/20">/10</span>
              </div>
            </div>
            <p className="text-sm text-white/80 leading-relaxed mb-6 font-medium">
              {vettingResult.reason}
            </p>
            {vettingResult.isMindful ? (
              <button 
                onClick={handleFinalPublish}
                className="w-full bg-white text-black font-black py-4 rounded-2xl hover:bg-[#E4FF1A] transition-all shadow-xl uppercase tracking-tighter"
              >
                Post Mindful Content
              </button>
            ) : (
              <div className="flex items-start gap-3 text-red-400 bg-red-400/5 p-4 rounded-2xl">
                <i className="fa-solid fa-circle-exclamation mt-1"></i>
                <div>
                  <p className="text-xs font-bold uppercase tracking-tight">Content Rejected</p>
                  <p className="text-[10px] opacity-60">This video does not meet our standards for intellectual or educational value.</p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      <p className="mt-8 text-[9px] text-center text-white/20 uppercase tracking-[0.3em] font-medium max-w-[200px] mx-auto leading-relaxed">
        AI is watching. Quality is non-negotiable.
      </p>
    </div>
  );
};

export default UploadView;
