
import { GoogleGenAI, Type } from "@google/genai";
import { ContentItem } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const vetContent = async (
  item: Partial<ContentItem>, 
  imagePart?: { inlineData: { data: string, mimeType: string } }
): Promise<{ isMindful: boolean; score: number; reason: string }> => {
  try {
    const textPrompt = `
      Analyze this content for "MindfulStream". 
      The core mission is to promote intellectual, educational, and positive content while stopping doomscrolling.
      
      PRIMARY TASK: Analyze the provided video frame to determine the intellectual quality. 
      Is it a lecture? A scientific demonstration? A philosophical discussion? A high-quality educational vlog?
      
      TITLE (Optional): ${item.title || "Not provided"}
      DESCRIPTION (Optional): ${item.description || "Not provided"}

      CRITICAL INSTRUCTION: Do not rely solely on the text provided. The visual evidence in the video frame is the primary source of truth. If the video frame shows mindless junk, rage-bait, or clickbait visuals, reject it regardless of a "good" title.
      
      Provide a mindfulness score from 0 to 10.
    `;

    const contents = imagePart 
      ? { parts: [imagePart, { text: textPrompt }] }
      : textPrompt;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: contents,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            isMindful: { type: Type.BOOLEAN },
            score: { type: Type.NUMBER },
            reason: { type: Type.STRING }
          },
          required: ["isMindful", "score", "reason"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Vetting failed:", error);
    return { isMindful: true, score: 7.0, reason: "Vetting service encountered an error. Defaulting to safe mode." };
  }
};
